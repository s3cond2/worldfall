Worldfall pack kit
==================

guide_examples/      The example pack from https://worldfall3d.com/modding/ : a dig shovel, an iron sword and a wolf.
                     Copy the folder into your packs folder (F2 > Mods > Manage > Pack folder), then turn it on there.
blend/               The three walkthroughs' finished Blender files.
worldfall_sizes.blend  The game's own models in meters, as you would build them: a person 1.75 m tall, held weapons
                     and tools on their grips, a wolf and an armchair. Model next to them, then export with
                     Include > Limit to > Selected Objects so they stay out of your file.

Everything here is in meters, Z up, models facing -Y. Needs Worldfall 0.9.8 or newer.
