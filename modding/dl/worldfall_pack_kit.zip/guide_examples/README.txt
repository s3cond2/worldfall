Guide examples - a Worldfall pack
=================================

The three models from https://worldfall3d.com/modding/ :
  models/tool_shovel.glb       the shovel you dig with in first person
  models/held_sword_iron.glb   the iron sword
  models/animal_wolf.glb       a wolf made of boxes (its fur takes the wolf sprite's colors)

Install: F2 > Mods > Manage > Pack folder, put this folder there, then move "Guide examples" from Available to Active.
